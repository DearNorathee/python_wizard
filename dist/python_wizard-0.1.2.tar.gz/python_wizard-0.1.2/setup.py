from setuptools import setup, find_packages

setup(
    author= "Dear Norathee",
    description="Package that would help shorten your python code providing additional functions ready to use",
    name="python_wizard",
    version="0.1.2",
    packages=find_packages(),
    license="MIT",
    install_requires=[""],
    

)